import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";

import {
getFirestore,
collection,
addDoc
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const firebaseConfig = {
apiKey: "AIzaSyALmmJ_nSdKhec2g2KQAsyZGT_SBsOiX7c",
  authDomain: "obu-muslim-students.firebaseapp.com",
  projectId: "obu-muslim-students",
  storageBucket: "obu-muslim-students.firebasestorage.app",
  messagingSenderId: "371443443287",
  appId: "1:371443443287:web:07760d84e0a7669ec92512"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const form = document.getElementById("studentForm");

form.addEventListener("submit", async (e) => {

e.preventDefault();

const fullname = document.getElementById("fullname").value;
const phone = document.getElementById("phone").value;
const email = document.getElementById("email").value;
const dob = document.getElementById("dob").value;
const age = document.getElementById("age").value;
const sex = document.getElementById("sex").value;
const address = document.getElementById("address").value;
const department = document.getElementById("department").value;
const studentStatus = document.getElementById("studentStatus").value;
const educationLevel = document.getElementById("educationLevel").value;
const religiousStudent = document.getElementById("religiousStudent").value;
const studyType = document.getElementById("studyType").value;

try {

await addDoc(collection(db,"students"),{

fullname:fullname,
phone:phone,
email:email,
dob:dob,
age:age,
sex:sex,
address:address,
department:department,
studentStatus:studentStatus,
educationLevel:educationLevel,
religiousStudent:religiousStudent,
studyType:studyType,
date:new Date()

});

document.getElementById("success").innerHTML="Registration Success ✅";

form.reset();

} catch(error){

console.error(error);

}

});